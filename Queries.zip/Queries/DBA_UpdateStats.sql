USE [Master_Masters]
GO

/****** Object:  StoredProcedure [dbo].[DBA_UpdateStats]    Script Date: 4/1/2021 12:11:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE procedure [dbo].[DBA_UpdateStats]
as 
Begin


DECLARE @table_name varchar(1000),@sql nvarchar(4000)  , @counter int

declare c1 cursor for 
	select 
	'['+ss.name+'].'+'['+so.name +']' name
from sys.objects so inner join sys.schemas ss
on so.schema_id=ss.schema_id

select @counter=1

open c1  
fetch next from c1 into @table_name  

while @@Fetch_Status = 0  
begin  
	Select @sql = 'UPDATE STATISTICS '+ @table_name +' WITH FULLSCAN, MAXDOP=0'  
	print convert(varchar,@counter)+' '+@sql  
	select @counter=@counter+1
	begin try
		exec sp_executesql @sql  
	end try
	begin catch
		print @sql
		print 'error'
	end catch
	fetch next from c1 into @table_name  
end  
close c1  
deallocate c1  
END



GO


