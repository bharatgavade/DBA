--sp_helptext STAGEBASED_REPORT

sp_spaceused temp_quotemailer_netcore
go
--Website_audit sp_spaceused whatsup_log
go
sp_spaceused sms_log
go
sp_spaceused quote_details 

1)sp_spaceused temp_quotemailer_netcore--1962287      Heap       
go
Select Count(QUOTE_NUMBER) as 'MailCount',QMN.CURRENTTABNAME,QMN.PRODUCTCODE, QMN.QUOTE_NUMBER from TEMP_QUOTEMAILER_netcore QMN  
  where QMN.ProductCode in ('2111','2311','2312','2334','2335','2336','2337','2338','2339','2340','2343','2347','2348','2349','2350','2351',  
  '2353','2354','2355','2358','2369','2372','2374','2613','2813','2816','2817','2818','2819','2820','2821','2825',  
  '2828','2833','2835','2837','2913','2352','2824','2849','2308','2309')  
     AND QMN.ProductCode IS NOT NULL  
     AND (QMN.SCHEDULER_REQUEST is not null or QMN.SCHEDULER_RESPONSE is not null)  
     group by QMN.CURRENTTABNAME,QMN.PRODUCTCODE, QMN.QUOTE_NUMBER  

go

2)sp_spaceused sms_log
go
Select Count(Ref_Value) as 'SMSCount', Ref_Value from SMS_LOG where Ref_Name = 'Quote Number' group By Ref_Value
go


3A)sp_spaceused quote_details 
go
declare	@FromDate  datetime, @EndDate  datetime 

Select ProductCode,CurrentTabName as 'Stages',Count(QuoteNo) as 'WebDropOut',QuoteNo,CreatedDate  
  
  ,(Select P.description from Product P where P.code = QD.ProductCode) as 'Product Name'    
  
  from Quote_Details QD   
  
  WHERE ProductCode in ('2111','2311','2312','2334','2335','2336','2337','2338','2339','2340','2343','2347','2348','2349','2350','2351',  
  '2353','2354','2355','2358','2369','2372','2374','2613','2813','2816','2817','2818','2819','2820','2821','2825','2828',  
        '2833','2835','2837','2913','2352','2824','2849','2308','2309')  
  
  --AND CreatedDate >= @FromDate   
  
  --AND CreatedDate<= @EndDate  
  
  --AND HCF_Quotes is null -- THIS CLAUSE SHOULD BE REMOVED Before Go Live   
  
    AND CurrentTAbName not like 'HCF_%'--REMOVED Before Go Live   
  AND FORMAT (CreatedDate, 'yyyy/MM/dd') >=  FORMAT (@FromDate, 'yyyy/MM/dd') --FromDate DATEADD(DAY,-20, getdate())  
  And FORMAT (CreatedDate, 'yyyy/MM/dd') <= FORMAT (@EndDate, 'yyyy/MM/dd') --ToDate  
  AND QD.PolicyType not in ( '3' ,'5')  
  GROUP BY ProductCode,CurrentTabName,QuoteNo,CreatedDate  
go

3B)sp_spaceused quote_details 
go

declare	@FromDate  datetime,  
    @EndDate  datetime 

  Select ProductCode,CurrentTabName as 'Stages',Count(QuoteNo) as 'WebDropOut',QuoteNo,CreatedDate  
  
  ,(Select P.description from Product P where P.code = QD.ProductCode) as 'Product Name'    
  from Quote_Details QD   
   WHERE ProductCode in ('2311','2312','2334','2335','2336','2337','2338','2339','2340','2343','2347','2348','2349','2350','2351','2353','2354','2355','2358','2369','2372','2374' ,'2352')  
   --AND CreatedDate >= @FromDate   
  
  --AND CreatedDate<= @EndDate  
  
  --AND HCF_Quotes is null -- THIS CLAUSE SHOULD BE REMOVED Before Go Live  
   AND CurrentTAbName not like 'HCF_%'--REMOVED Before Go Live   
  
  AND FORMAT (CreatedDate, 'yyyy/MM/dd') >=  FORMAT (@FromDate, 'yyyy/MM/dd') --FromDate DATEADD(DAY,-20, getdate())  
 
  And FORMAT (CreatedDate, 'yyyy/MM/dd') <= FORMAT (@EndDate, 'yyyy/MM/dd') --ToDate  
  
  AND QD.PolicyType = '3'  
  AND QD.CurrentTabName is not null  
 
  GROUP BY ProductCode,CurrentTabName,QuoteNo,CreatedDate  
 go
 
4)sp_spaceused whatsup_log
go  
Select Count(Quote_Number) as 'WhatsappCount', Quote_Number from Website_audit.dbo.Whatsapp_Log where  Quote_Number is null group By Quote_Number
