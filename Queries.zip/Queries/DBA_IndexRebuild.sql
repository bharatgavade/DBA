USE [XPAS]
GO

/****** Object:  StoredProcedure [dbo].[DBA_IndexRebuild]    Script Date: 4/1/2021 12:08:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE procedure [dbo].[DBA_IndexRebuild]
as 
Begin

CREATE TABLE #rebuildfrag(
[ID] [int] IDENTITY(1,1) NOT NULL,
[DatabaseName] [varchar](2000) NULL,
[ObjectName] [varchar](2000) NULL,
[Index_id] [int] NULL,
[indexName] [varchar](2000) NULL,
[avg_fragmentation_percent] [float] NULL,
[IndexType] [varchar](2000) NULL,
[Action_Required] [varchar](2000) NULL,
[page_count] [int] NULL,
[DateTime] [datetime] NULL,
[SchemaName] [nvarchar](50) NULL
) ON [PRIMARY]

-- fragmentation data collection step

insert into #rebuildfrag(DatabaseName,SchemaName,ObjectName,Index_id, indexName,avg_fragmentation_percent,page_count,IndexType,DateTime)
SELECT 
db_name() as DatabaseName, 
QUOTENAME(OBJECT_SCHEMA_NAME(a.object_id, database_id)) schemaName,
OBJECT_NAME (a.object_id) as ObjectName, 
a.index_id, b.name as IndexName, 
avg_fragmentation_in_percent, page_count,index_type_desc,GETDATE() as DateTime
FROM 
sys.dm_db_index_physical_stats (db_id(), NULL, NULL, NULL, NULL) AS a
JOIN sys.indexes AS b ON a.object_id = b.object_id AND a.index_id = b.index_id
WHERE b.index_id <> 0 and avg_fragmentation_in_percent <>0

-- flagging index that needs to be rebuild (here considered indexes where fragmentation is more than 20% and having data scaterred in more than 1000 pages)
update #rebuildfrag
set Action_Required ='Rebuild'
where avg_fragmentation_percent >20 and page_count>=1000 and databasename =db_name()

select  
row_number()  over( order by id) as Rank,* into  #temp  
from  #rebuildfrag
where 
avg_fragmentation_percent > 20 and page_count > 1000
and databasename =db_name()

-- loop for reindexing

DECLARE @StartTime datetime
Declare @cnt int
Declare @maxid int
Declare @IndexRebuildDurationSeconds int
Declare @TableName as varchar(max)
Declare @IndexName as varchar(max)
declare @sql as varchar(max)
Declare @dbname as varchar(max)
Declare @SchemaName as varchar(max)

set @cnt=1

SELECT @MAXID =max(rank) from #temp

while (@cnt<=@maxid)
Begin

SET @SchemaName = (select SchemaName from  #temp  where RANK=@cnt)
SET @TableName =@SchemaName+'.'+'['+(select Objectname from #temp where RANK=@cnt)+']' 

SET @IndexName = (select IndexName from #temp where RANK=@cnt )
SET @StartTime = Getdate()
SET @dbname = (Select DatabaseName from   #temp where RANK=@cnt) 

set @sql=      
'use [' + @dbname + ']      
ALTER INDEX ['+@IndexName+'] ON '+@TableName+' REBUILD PARTITION = ALL WITH (MAXDOP=0, PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, ONLINE = off, SORT_IN_TEMPDB = off )'

PRINT  (@sql)

Exec (@sql)
 
SET @IndexRebuildDurationSeconds = DATEDIFF(ss, @StartTime, Getdate())
print @IndexRebuildDurationSeconds

set @cnt =@cnt +1

End

drop table   #temp
drop table #rebuildfrag

END





GO


