--insert into #AMOL
--(
IF OBJECT_ID('DBAADMIN.dbo.#AMOL') IS Not Null
BEGIN    
TRUNCATE TABLE DBAADMIN.dbo.#AMOL
END       
use dbaadmin
go
create table DBAADMIN.dbo.#AMOL(
job_id varchar(25),start_execution_date datetime,stop_execution_date  datetime
)
insert into DBAADMIN.dbo.#AMOL

select s.job_id,s.start_execution_date,s.stop_execution_date 
from msdb.dbo.sysjobactivity
declare @val varchar(10)
set @val ='null'
SELECT top 1 job_id,start_execution_date,stop_execution_date 
FROM msdb.dbo.sysjobactivity s


if stop_execution_date = 'null' then
exec msdb..sp_stop_job 'DBA_deadlock' 

WHERE start_execution_date IS NOT NULL AND stop_execution_date IS NULL
   AND job_id='FC1BF3EC-B184-4DAB-9F05-A458935315A0'
   order by start_execution_date desc
  
  

  -- If sja.stop_execution_date = NULL

  SELECT * FROM MSDB..sysjobactivity WHERE job_id='FC1BF3EC-B184-4DAB-9F05-A458935315A0'

SELECT * FROM MSDB..SYSJOBS WHERE NAME LIKE '%DBA_DEADLOCK%'



SELECT top 1 sj.name
   , sja.*
FROM msdb.dbo.sysjobactivity AS sja
INNER JOIN msdb.dbo.sysjobs AS sj ON sja.job_id = sj.job_id
WHERE sja.start_execution_date IS NOT NULL
   AND sja.stop_execution_date IS NULL
   and name ='DBA_deadlock'   
   order by sja.start_execution_date desc







--   If 
--   (
--   select status = 'runnable' from sys.sysprocesses where program_name like '%0xECF31BFC84B1AB4D9F05A458935315A0%'
--   go
--   exec msdb..sp_stop_job 'DBA_deadlock'    
--   )
--   select status = 'runnable' from sys.sysprocesses where program_name like '%0xECF31BFC84B1AB4D9F05A458935315A0%'

----   SQLAgent - TSQL JobStep (Job 0xECF31BFC84B1AB4D9F05A458935315A0 : Step 1)