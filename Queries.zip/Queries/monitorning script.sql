exec [sp_WhoIsActive_new]   @get_plans=1

exec sp_rootblocker

dbcc inputbuffer(92)

select @@servername

select session_id,percent_complete,DB_name(database_id) from sys.dm_exec_requests
where command like 'Backup%' or command like '%DBCC%'

---------------Blocking Details--------------------------

SELECT blocking.session_id AS blocking_session_id , blocked.session_id AS blocked_session_id , 
waitstats.wait_type AS blocking_resource , waitstats.wait_duration_ms , 
waitstats.resource_description , blocked_cache.text AS blocked_text ,
 blocking_cache.text AS blocking_text 
FROM sys.dm_exec_connections AS blocking 
INNER JOIN sys.dm_exec_requests blocked ON blocking.session_id = blocked.blocking_session_id 
CROSS APPLY sys.dm_exec_sql_text(blocked.sql_handle) blocked_cache
CROSS APPLY sys.dm_exec_sql_text(blocking.most_recent_sql_handle) blocking_cache 
INNER JOIN sys.dm_os_waiting_tasks waitstats ON waitstats.session_id = blocked.session_id

---------------------------------------------------------

select db_name(dbid),* from sys.sysaltfiles where filename like '%D:%'
select * from sys.sysprocesses where status <> 'sleeping' and loginame = 'irpas'  

--use tempdb
--go
--SELECT * FROM sys.dm_tran_session_transactions
                                                                                                                     
sp_who4_new
sp_who5
sp_helpdb tempdb
go
sp_helpdb master
go
sp_helpdb model
go
sp_helpdb msdb
go
xp_fixeddrives
sp_who2 active
sp_who2 213

select * from DBAAdmin.dbo.DBA_Drive_Space

--select count(1) from WORKDONETABLE

--select io_type,count(*) from sys.dm_io_pending_io_requests
--group by io_type

---------- For AG ----------

select @@SERVERNAME Hostname,db_name(database_id) DBName, recovery_lsn,truncation_lsn,last_hardened_lsn,last_received_lsn,last_redone_lsn,last_redone_time 
from sys.dm_hadr_database_replica_states

--DBCC TRACEON(3459,-1) --If there is redolog pendency
--GO
--------------------------------------------------------
--select 'kill '+ convert(varchar,spid ) from sysprocesses where dbid=DB_ID('AuditTrailMQ') and spid<>'143'
--kill 72

dbcc sqlperf(logspace)

dbcc opentran

select sp.spid, DB_NAME(sp.dbid) as dbname,lastwaittype,cmd,text,sp.blocked,sp.waitresource, 
p.required_memory_kb,p.granted_memory_kb,p.used_memory_kb,p.query_cost
,sp.cpu,sp.physical_io,* from sys.sysprocesses sp
cross apply sys.dm_exec_sql_text(sp.sql_handle) sh
left join sys.dm_exec_query_memory_grants p
on sp.spid=p.session_id
where status<>'sleeping' and sp.spid<>@@SPID --and sh.objectid=1780969471
order by sp.login_time asc


select  sp.lastwaittype, count(sp.lastwaittype) from sys.sysprocesses sp
cross apply sys.dm_exec_sql_text(sp.sql_handle) sh
left join sys.dm_exec_query_memory_grants p
on sp.spid=p.session_id
where status<>'sleeping' and sp.spid<>@@SPID 
group by sp.lastwaittype
order by count(sp.lastwaittype) desc

-- Get a count of SQL connections by IP address (Query 39) (Connection Counts by IP Address)
SELECT ec.client_net_address, es.[program_name], es.[host_name], es.login_name, 
COUNT(ec.session_id) AS [connection count] 
FROM sys.dm_exec_sessions AS es WITH (NOLOCK) 
INNER JOIN sys.dm_exec_connections AS ec WITH (NOLOCK) 
ON es.session_id = ec.session_id 
GROUP BY ec.client_net_address, es.[program_name], es.[host_name], es.login_name  
ORDER BY ec.client_net_address, es.[program_name] OPTION (RECOMPILE);
------


---------Uptime---------
SELECT DATEADD(ms,-sample_ms,GETDATE() )AS StartTime
FROM sys.dm_io_virtual_file_stats(1,1);

---------------------------------Memory Grants-------------------------------


SELECT mg.granted_memory_kb, mg.session_id, t.text, qp.query_plan 
FROM sys.dm_exec_query_memory_grants AS mg
CROSS APPLY sys.dm_exec_sql_text(mg.sql_handle) AS t
CROSS APPLY sys.dm_exec_query_plan(mg.plan_handle) AS qp
ORDER BY 1 DESC OPTION (MAXDOP 1)


select status,count(*) as NOofCount from sys.sysprocesses group by status

select name,state_desc,log_reuse_wait,log_reuse_wait_desc,* from sys.databases 
where log_reuse_wait_desc<>'nothing'

select login_name, COUNT(session_id) as cnt from sys.dm_exec_sessions
where status<>'sleeping'
group by login_name
order by COUNT(session_id) desc

exec sp_readerrorlog
exec sp_readerrorlog ' ','1',' ' ,'backed'
exec sp_readerrorlog ' ','1',' ' ,'BACKUP failed'
exec sp_readerrorlog ' ','1',' ' ,'deadlock'
exec sp_readerrorlog ' ','1',' ' ,'error'
exec sp_readerrorlog ' ','1',' ' ,'I/O'

--to check failed jobs--change date
select distinct b.name,a.run_date from msdb..sysjobhistory a ,msdb..sysjobs b where
a.job_id=b.job_id
and run_status=0
and a.run_date>=20151127
                      
--msdb..sp_start_job 'DBA_Daily_Report_new'

----To Search long running job from job ID----

select * from msdb..sysjobs where job_id = [enter job id from output of sys.sysprocesses.programname here without qoutation marks]


SELECT DB_NAME() AS DbName, 
name AS FileName, 
size/128.0 AS CurrentSizeMB, 
size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS INT)/128.0 AS FreeSpaceMB 
FROM sys.database_files; 
