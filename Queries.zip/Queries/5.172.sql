DBCC TRACEON (3604);
GO

/* DBCC PAGE (DatabaseName, FileNumber, PageNumber, DumpStyle)*/
DBCC PAGE ('RGIDCTMSQLPRODDB',1,135812988,2);
GO


--7:1:152522342--ObjectId = 1493580359--IndexId = 30
--7:1:111254296--ObjectId = 1493580359--
--7:1:153558117

dbcc tracestatus

SELECT 
    sc.name as schema_name, 
    so.name as object_name, 
    si.name as index_name
FROM sys.objects as so 
JOIN sys.indexes as si on 
    so.object_id=si.object_id
JOIN sys.schemas AS sc on 
    so.schema_id=sc.schema_id
WHERE 
    so.object_id = 1493580359
    and si.index_id = 30;
GO

--table--dm_sysobject_s
--index--IDX_SYS_SURVEY


select all rgi_policy.r_object_id from rgi_policy_sp  rgi_policy 
where ((rgi_policy.policy_id=N'120821823120127958') and (rgi_policy.r_is_virtual_doc=N'1') 
and (rgi_policy.a_content_type!=N' ')) and (rgi_policy.i_has_folder = 1 and rgi_policy.i_is_deleted = 0)